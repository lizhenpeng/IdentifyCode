package com.lizhenpeng.test;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.lizhenpeng.core.IdentifyCode;

public class ProjectTestCode {

	public static void main(String[] args) throws FileNotFoundException {
		IdentifyCode ins = IdentifyCode.getInstance();
		//��������Ĵ�С
		ins.setFontSize(30);
		//������֤��ͼƬ�ĳߴ�
		ins.setcodeImageSize(200,60);
		String result = ins.createCodeImage();
		System.out.println(result);
		FileOutputStream out = new FileOutputStream("d:\\test.jpeg");
		//�������
		ins.WriteImageData(out);
	}

}
