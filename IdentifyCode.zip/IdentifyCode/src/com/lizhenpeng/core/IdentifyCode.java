package com.lizhenpeng.core;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;

public class IdentifyCode {
	
	
	//---------- Instance Variables --------------------------------------------------------------------
	
	
	private BufferedImage codeImage;     //�����������֤��
	private Color fontColor;
	private String backgroundcodeImagePath;      //�����б���ͼƬ����֤��
	private int codeImageWidth = 200;      //������֤��Ŀ���
	private int codeImageHeight = 60;      //������֤��ĸ߶�
	private String fontName = "����";      //������֤��ʹ�õ�����
	private int fontSize = 14;        //������֤�������ĳߴ�
	private int stringLength = 4;       //���ɵ���֤����ַ��ĸ���
	private String saveString = "";        //�������ɵ���֤��
	private String codeImageType = "JPEG";      //��֤��ͼƬʹ�õĸ�ʽ
	private boolean InterfereLine = true;
	private String stringContent = "23456789abcdefghijklmnpqrstuvwxyz";   //���ɵ���֤���ַ���ȡֵ����
	private Color backgroundColor = Color.WHITE;    //Ĭ�ϵı�����ɫ
	
	
	//---------- Constructor -------------------------------------------------------------------
	
	
	private IdentifyCode() {
		//hide constructor
	}
	
	
	//---------- Properties ----------------------------------------------------------------------------
	
	
	public static IdentifyCode getInstance() {
		return new IdentifyCode();
	}
	
	public void setStringInterval(String content) {
		stringContent = content;
	}
	
	public void setBackgroundPath(String filePath) {
		backgroundcodeImagePath = filePath;
	}
	
	public void setcodeImageSize(int width,int height) {
		codeImageWidth = width;
		codeImageHeight = height;
	}
	
	public int getcodeImageWidth() {
		return codeImageWidth;
	}
	
	public int getcodeImageHeight() {
		return codeImageHeight;
	}
	
	public void setFont(String font) {
		fontName  = font;
	}
	
	public String getFontName() {
		return fontName;
	}
	
	public void setFontSize(int size) {
		fontSize = size;
	}
	
	public int getFontSize() {
		return fontSize;
	}
	
	public void setStringLength(int length) {
		stringLength = length;
	}
	
	public int getStringLength() {
		return stringLength;
	}
	
	public void setBackgroundColor(Color color) {
		backgroundColor = color;
	}
	
	public Color getBackgroundColor() {
		return backgroundColor;
	}
	
	public Color getFontColor() {
		return fontColor;
	}
	
	public void setFontColor(Color ins) {
		fontColor = ins;
	}
	
	public String getResultString() {
		return saveString;
	}
	
	public boolean getInterfereLine() {
		return InterfereLine;
	}
	
	public void setCreateInterfereLine(boolean on) {
		InterfereLine = on;
	}
	
	
	//----------- Public Methods -----------------------------------------------------------------------
	
	private Color getColor() {
		if(fontColor != null) {
			return fontColor;
		}
		return randomColor();
	}
	
	private Color randomColor() {
		int R = (int)(Math.random()*256);
		int G = (int)(Math.random()*256);
		int B = (int)(Math.random()*256);
		return new Color(R,G,B);
	}
	
	private void drawBackground(Graphics2D graphics) {
		drawBackgroudColor(graphics);
		if(backgroundcodeImagePath != null) {
			drawBackgroundcodeImage(graphics);
		}
	}
	
	private void drawBackgroudColor(Graphics2D graphics) {
		Color saveColor = graphics.getColor();
		graphics.setPaint(backgroundColor);
		graphics.fillRect(0, 0, codeImageWidth, codeImageHeight);
		graphics.setColor(saveColor);
	}
	
	private void drawBackgroundcodeImage(Graphics2D graphics) {
		File file = new File(backgroundcodeImagePath);
		if(file.exists()) {
			try {
				BufferedImage codeImage = ImageIO.read(file);
				graphics.drawImage(codeImage,0,0,codeImageWidth,codeImageHeight,null);
			} catch (IOException e) {
				System.out.println("BackgroundcodeImage Not Exists!");
			}
		}
	}
	
	//����һ������ĸ߶�(������)
	private int createPointY() {
		int height = codeImageHeight / 2;
		return (int) (Math.random()*height + height/4);
	}
	
	//ʹ�ø�����
	private void drawInterfereLine(Graphics2D graphics) {
		if(InterfereLine) {
			int pointX = codeImageWidth / 2;
			int pointY = createPointY();
			graphics.setStroke(new BasicStroke(3f));
			graphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.6f));
			graphics.setPaint(randomColor());
			Line2D line = new Line2D.Double(codeImageWidth/4*0.5,createPointY(),pointX,pointY);
			Line2D endLine = new Line2D.Double(pointX, pointY, codeImageWidth/4*3.5,createPointY());
			graphics.draw(line);
			graphics.setPaint(randomColor());
			graphics.draw(endLine);
		}
	}
	
	//��������ַ�
	private String randomString() {
		int length = stringContent.length();
		int position = (int)(Math.random()*length);
		return stringContent.substring(position,position+1);
	}
	
	//����仯��������
	private double randomRotate() {
		return (Math.PI/180)*((Math.random()*75) -35);
	}
	
	private float randomScale() {
		return (float)(Math.random()*0.6+0.8);
	}
	
	private String drawString(Graphics2D graphics) {
		Font font = new Font(fontName,Font.BOLD,fontSize);
		graphics.setFont(font);
		StringBuilder builder = new StringBuilder();
		int everyCharWidth = (int)(codeImageWidth*(1f/(stringLength)));
		//��ȡ���������Ļ���
		FontRenderContext fontContext = graphics.getFontRenderContext();
		//��ʼ����ͼƬ
		int index = 0;
		for( ; index < stringLength ; index++) {
			String string = randomString();
			builder.append(string);
			Rectangle2D rect = font.getStringBounds(string,fontContext);
			//�������ɫ
			Color color = getColor();
			graphics.setPaint(color);
			//�ַ�����ʾ��λ�õĸ߶�
			int xPosition = everyCharWidth * index + (int)(rect.getWidth() / 2);
			int yPosition = codeImageHeight*3/4;
			double rotateAngle = randomRotate();
			float randomScale = randomScale();
			//��������ı任
			graphics.translate(xPosition, yPosition);
			graphics.rotate(rotateAngle);
			graphics.scale(randomScale,randomScale);
			graphics.drawString(string, 0,0);
			//�ָ�����ϵ��״̬
			graphics.rotate(-rotateAngle);
			graphics.scale(1/randomScale,1/randomScale);
			graphics.translate(-xPosition, -yPosition);
		}
		return new String(builder);
	}
	
	//�������������
	public void WriteImageData(OutputStream out) {
		try {
			ImageIO.write(codeImage,codeImageType,out);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//������֤��ͼƬ
	public String createCodeImage() {
		codeImage = new BufferedImage(codeImageWidth,codeImageHeight,BufferedImage.TYPE_INT_BGR);
		Graphics2D graphics = (Graphics2D) codeImage.getGraphics();
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		drawBackground(graphics);
		saveString = drawString(graphics);
		drawInterfereLine(graphics);
		graphics.dispose();
		return saveString;
	}
}
